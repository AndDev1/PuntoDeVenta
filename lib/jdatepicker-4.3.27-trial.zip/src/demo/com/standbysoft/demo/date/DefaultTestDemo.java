/*
 * @(#)DefaultTestDemo.java
 *
 * Copyright (c) 2003-2004 Stand By Soft, Ltd. All rights reserved.
 *
 * This software is the proprietary information of Stand By Soft, Ltd.  
 * Use is subject to license terms.
 */
package com.standbysoft.demo.date;

/**
 * A class that can be used to write a quick test.
 */
public class DefaultTestDemo {
	public DefaultTestDemo() {
	}

	public static void main(String[] args) {
		new DefaultTestDemo();
	}
}